function y = fft2_filtered(x)
        % y=real(fft2(x)); 
        y=fft2(x);
end