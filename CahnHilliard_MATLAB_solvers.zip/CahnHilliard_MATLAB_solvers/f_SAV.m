function fphi = f_SAV(phi,gamma0)
    fphi = (phi.^2-1-gamma0).^2/4;
end