function fphi = f(phi)
    % f = @(x) 0.25*(x.^2-1).^2
    fphi = (phi.^2-1).^2/4;
end