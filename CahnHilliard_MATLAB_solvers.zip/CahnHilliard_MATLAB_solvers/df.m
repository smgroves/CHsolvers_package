function dfphi = df(phi,gamma0)
    dfphi = (phi.^3-(1+gamma0)*phi);
end